import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../application/bloc/counter_bloc.dart';
import '../../application/bloc/counter_event.dart';
import '../../application/bloc/counter_state.dart';

class CounterScreen extends StatelessWidget {
  const CounterScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // 1. Provide the BLoC instance to the widget tree
    return BlocProvider(
      create: (context) => CounterBloc(),
      child: Scaffold(
        appBar: AppBar(title: const Text('BLoC Counter Example')),
        body: Center(
          // 2. Listen to state changes and rebuild UI accordingly
          child: BlocBuilder<CounterBloc, CounterState>(
            builder: (context, state) {
              return Text('Count: ${state.count}', style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold));
            },
          ),
        ),
        floatingActionButton: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            FloatingActionButton(
              heroTag: 'increment',
              // 3. Dispatch events using context.read<BlocType>()
              onPressed: () => context.read<CounterBloc>().add(CounterIncrementPressed()),
              child: const Icon(Icons.add),
            ),
            const SizedBox(height: 10),
            FloatingActionButton(
              heroTag: 'decrement',
              onPressed: () => context.read<CounterBloc>().add(CounterDecrementPressed()),
              child: const Icon(Icons.remove),
            ),
          ],
        ),
      ),
    );
  }
}
